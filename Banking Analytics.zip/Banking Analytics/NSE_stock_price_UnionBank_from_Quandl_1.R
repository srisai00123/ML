# Quandl package must be installed
#install.packages("devtools")
library(devtools)
#install_github("quandl/quandl-r")
library(Quandl)
library(ggplot2)
library(dplyr)
library(plotly)
library(TTR)
library(tseries)
library(forecast)



#TIME SERIES ANALYSIS

# Get your API key from quandl.com
quandl_api = "gQxVoyzG7UT5GEzvibtD"

# Add the key to the Quandl keychain
Quandl.api_key(quandl_api)

#Getting NIFTY Data using yahoodata.
UNIONBANK=Quandl("NSE/UNIONBANK",start_date="2011-01-01",type = "xts")

NIFTY=Quandl("NSE/CNX_NIFTY",start_date ="2011-01-01",type = "xts")


#Monthly Data

#NSE Data
UNIONBANKdata_Mon<-getYahooData("UNIONBANK.NS",20110101,freq = "monthly",type = "price",adjust = FALSE)

UNIONBANKdata_Mon<-UNIONBANKdata_Mon[,"Close"]

UNIONBANKdatatimeseries_Mon <- ts(UNIONBANKdata_Mon, frequency=12, start=c(2011,01), end=c(2018,03))

plot.ts(UNIONBANKdatatimeseries_Mon)

#weekly Data

#NSE Data
UNIONBANKdata_Week<-getYahooData("UNIONBANK.NS",20110101,freq = "weekly",type = "price",adjust = FALSE)

UNIONBANKdata_Week<-UNIONBANKdata_Week[,"Close"]

UNIONBANKdatatimeseries_Week <- ts(UNIONBANKdata_Week)

plot.ts(UNIONBANKdatatimeseries_Week)


#Daily Data

#NSE Data
UNIONBANKdata_Day<-getYahooData("UNIONBANK.NS",20110101,freq = "daily",type = "price",adjust = FALSE)

UNIONBANKdata_Day<-UNIONBANKdata_Day[,"Close"]

UNIONBANKdatatimeseries_Day <- ts(UNIONBANKdata_Day)

plot.ts(UNIONBANKdatatimeseries_Day)


#Decompose we will find random components and to observe trend and seasonality


#using decompose we will find random components and to observe trend and seasonality.
UNIONBANKde<-decompose(UNIONBANKdatatimeseries_Mon)

names(UNIONBANKde)

plot(UNIONBANKde)


#Checking whether data is stationary or not


#adf(argumented dickey fuller) to identify data stationary or non stationary if stationary then only

adf.test(tsclean(UNIONBANKde$random))


#Returns and Beta Calculation

#DAILY

idbi_daily = dailyReturn(UNIONBANK)
nifty_daily = dailyReturn(NIFTY)
dailyrets = na.omit(merge(nifty_daily,idbi_daily))
names(dailyrets)=c("nifty","ubi")
View(tail(dailyrets,10))

dailybeta=cov(dailyrets$nifty,dailyrets$ubi)/var(dailyrets$nifty)
View(dailybeta)


#WEEKLY

idbi_weekly =weeklyReturn(UNIONBANK)
nifty_weekly = weeklyReturn(NIFTY)
weekly_return =na.omit(merge(nifty_weekly,idbi_weekly))
names(weekly_return)=c("nifty","ubi")
View(tail(weekly_return,10))

weeklybeta = cov(weekly_return$nifty,weekly_return$ubi)/var(weekly_return$nifty)
View(weeklybeta)

#MONTHLY

idbi_monthly = monthlyReturn(UNIONBANK)
nifty_monthly = monthlyReturn(NIFTY)
monthly_return =na.omit(merge(nifty_monthly,idbi_monthly))
names(monthly_return)=c('nifty',"ubi")
View(tail(monthly_return,10))

monthlybeta =cov(monthly_return$nifty,monthly_return$ubi)/var(monthly_return$nifty)
View(monthlybeta)

#YEARLY

idbi_yearly =yearlyReturn(UNIONBANK)  
nifty_yearly = yearlyReturn(NIFTY)
yearly_return = na.omit(merge(nifty_yearly,idbi_yearly))
names(yearly_return)=c("nifty","ubi")
View(tail(yearly_return,10))

yearlybeta = cov(yearly_return$nifty,yearly_return$ubi)/var(yearly_return$nifty)
View(yearlybeta)

#Net Profit Year wise
Years<-c("2017","2016","2015","2014","2013")
Netprofit_in_crores<-c("555.21","1352.02","1782.05","1696.61","2158.54")
Netprofit_in_crores<-as.numeric(Netprofit_in_crores)
Netprofit_data <- data.frame(Years, Netprofit_in_crores)
ggplot(Netprofit_data,aes(x=Years,y=Netprofit_in_crores,label = Netprofit_in_crores)) +
  geom_bar(stat = "identity") +
  geom_text(size = 3, position = position_stack(vjust = 1.05))

#Earn Per share
Years_per<-c("2017","2016","2015","2014","2013")
Earn_pershare_in_crore<-c("8.08","19.66","27.94","26.75","36.00")
Earn_pershare_in_crore<-as.numeric(Earn_pershare_in_crore)
Earn_pershare_data <- data.frame(Years_per, Earn_pershare_in_crore)
ggplot(Earn_pershare_data,aes(x=Years_per,y=Earn_pershare_in_crore,label = Earn_pershare_in_crore)) +
  geom_bar(stat = "identity") +
  geom_text(size = 3, position = position_stack(vjust = 1.05))

#ARIMA & FORECAST for on week

## Download the data Set
UNIONBANK = Quandl("NSE/UNIONBANK",collapse="daily",start_date="2018-01-01",type="raw")


## Convert the UNIONBANK of India Data Set into df for regression model

UNIONBANK_df=UNIONBANK

colnames(UNIONBANK_df)<-c("Date","Open","High","Low","Last","Close","TTQ","Turnover")


## Change the scale of Trade quantity

UNIONBANK_df$TTQ<-UNIONBANK_df$TTQ/100000

## Regression models

m1=lm(UNIONBANK_df$Close~UNIONBANK_df$High+UNIONBANK_df$Low+UNIONBANK_df$TTQ)

p1.df=as.data.frame(predict(m1,interval="predict"))

## Forecast using ARIMA to take out the seasonality and cyclic part of the stock

m2=arima(diff(UNIONBANK_df$Close),order=c(1,0,0))

p2.df=as.data.frame(predict(m2,n.ahead=7))


## Combining the Random and Stock  together

p1.df=p1.df[1:7,]
p1.df$fit=p1.df$fit+p2.df$pred

## Create the date df for next three months

date<-as.data.frame(as.Date(c("2018-03-22","2018-03-23","2018-03-26","2018-03-27","2018-03-28","2018-03-29","2018-03-30")))
colnames(date)=c("date")

## Modify the predict dataset and add "key" variable for UNIONBANK

p1.df<-cbind(p1.df,date)
p1.df["Key"]<-"Predicted"
p1.df<-p1.df[,c("date","fit","lwr","upr","Key")]

## Rename the columns
colnames(p1.df)<-c("Date","Close","lwr","upr","Key")

## Modify the UNIONBANK_df dataset

UNIONBANK_df<-UNIONBANK%>%select("Date","Close")

## Add two variable for confidence interval "lwr" and "upr"
var<-c("lwr","upr")

UNIONBANK_df[var]<-NA

## Add the Key variable for Actual data

UNIONBANK_df["Key"]<-"Actual"

## Rbind the predicted and actual value for both of the Stocks

UNIONBANK_com=rbind(UNIONBANK_df,p1.df)
UNIONBANK_com$Date<-as.Date(UNIONBANK_com$Date)

## Visualisation
ggplot(data=UNIONBANK_com,aes(x= Date, y = Close,color=Key,label=Close)) +
  # Prediction intervals
  geom_ribbon(aes(ymin = lwr, ymax = upr, fill = Key), 
              fill = "khaki2", size = 0)+
  geom_line(size = 1.7) + 
  geom_point(size = 2)+
  labs(title = "Actual and Predicted Price UNION BANK OF INDIA 2018", x = "Date",y="Price") +
  theme(text = element_text(family = 'Gill Sans', color = "#444444",hjust=0.5)
        ,panel.background = element_rect(fill = "honeydew")
        ,panel.grid.minor = element_blank()
        ,panel.grid.major = element_blank()
        ,plot.title = element_text(size = 20,hjust=0.5,colour="orangered4")
        ,axis.title = element_text(size = 18, color = '#555555')
        ,axis.title.y = element_text(hjust=0.5,size=15)
        ,axis.title.x = element_text(hjust = 0.5,size=15))

#ARIMA & FORECAST for 90 days 

model=auto.arima(UNIONBANK$Close)
model


pred <- forecast(model,h= 90)
plot(pred)

