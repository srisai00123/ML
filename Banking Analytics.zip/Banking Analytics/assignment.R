
library(Quandl)
Quandl.api_key("bc18chnkUfZh_Yedubhn")

pnb_stock <- Quandl("NSE/PNB",order = "asc")[,c("Date","Close")]


library(ggplot2)
library(plotly)

ggplot(pnb_stock,aes(x=format(Date,"%Y-%m-%d"),y=Close))+
  geom_line(group =1)+
  xlab("Year")+
  theme(axis.text.x = element_blank())

ggplotly(p)




library(forecast)
library(tseries)

pnb_stock_ts <- ts(pnb_stock$Close,frequency = 250)
decom <- decompose(pnb_stock_ts,type = "multiplicative")
plot(decom)




pnb_stock$month <- format(pnb_stock$Date,format("%m"))
pnb_stock$year <- format(pnb_stock$Date,format("%Y"))

pnb_stock %>% filter(year == 2017) %>% group_by(month) %>% summarise(month_avg = mean(Close)) %>%
  ggplot(aes(x=month,y=month_avg))+
  geom_line(aes(group = 1))+
  theme_bw()+
  ggtitle("Month wise average 2017")



pnb_stock %>% filter(year == 2015) %>% group_by(month) %>% summarise(month_avg = mean(Close)) %>%
  ggplot(aes(x=month,y=month_avg))+
  geom_line(aes(group = 1))+
  theme_bw()+
  ggtitle("Month wise average 2017")


pnb_stock_d <- Quandl("NSE/PNB",order = "asc",transform = "rdiff")[,c("Date","Close")]
nse_index_d <- Quandl("NSE/CNX_NIFTY",order = "asc",transform = "rdiff")[,c("Date","Close")]
pnb_stock_d <- merge(pnb_stock_d,nse_index_d,by = "Date",all.x = T)


regressor_d <- lm(Close.x ~ Close.y,data = pnb_stock_d)
beta_daily <- regressor_d$coefficients[2]
beta_daily



pnb_stock_w <- Quandl("NSE/PNB",order = "asc",collapse = "weekly",transform = "rdiff")[,c("Date","Close")]
nse_index_w <- Quandl("NSE/CNX_NIFTY",order = "asc",collapse = "weekly",transform = "rdiff")[,c("Date","Close")]

pnb_stock_w <- merge(pnb_stock_w,nse_index_w,by = "Date",all.x = T)


regressor_w <- lm(Close.x ~ Close.y,data = pnb_stock_w)
beta_weekly <- regressor_w$coefficients[2]
beta_weekly




pnb_stock_m <- Quandl("NSE/PNB",order = "asc",collapse = "monthly",transform = "rdiff")[,c("Date","Close")]
nse_index_m <- Quandl("NSE/CNX_NIFTY",order = "asc",collapse = "monthly",transform = "rdiff")[,c("Date","Close")]

pnb_stock_m <- merge(pnb_stock_m,nse_index_m,by = "Date",all.x = T)


regressor_m <- lm(Close.x ~ Close.y,data = pnb_stock_m)
beta_monthly <- regressor_m$coefficients[2]
beta_monthly






model <- auto.arima(pnb_stock_ts)

model


pred <- forecast(model,h= 90)
plot(pred)

pred$mean


plot(regressor_d)




